# Kushi A S – Portfolio

Live Portfolio: [https://kushias7.github.io/kushi-portfolio](https://kushias7.github.io/kushi-portfolio)

## Setup
1. Upload all files to your `kushi-portfolio` GitHub repository.
2. Add your resume PDF to `assets/resume.pdf`.
3. Go to Settings → Pages → Enable GitHub Pages (Source: main branch/root).

## Features
- About, Skills, Projects, Resume
- Dark mode toggle
- GitHub stats integration
